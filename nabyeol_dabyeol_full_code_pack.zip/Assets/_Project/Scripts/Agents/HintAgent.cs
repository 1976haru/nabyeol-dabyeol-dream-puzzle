using System.Collections.Generic;
using UnityEngine;
using NabyeolDabyeolDreamPuzzle.Puzzle;
namespace NabyeolDabyeolDreamPuzzle.Agents
{
    public class HintAgent : MonoBehaviour
    {
        public struct HintResult{ public bool hasHint; public Block firstBlock,secondBlock; public int expectedMatchCount; public static HintResult None=>new HintResult(); public HintResult(Block a,Block b,int n){firstBlock=a;secondBlock=b;expectedMatchCount=n;hasHint=a!=null&&b!=null&&n>0;} }
        [SerializeField] private MatchFinder matchFinder; [SerializeField,Min(1)] private int maxCheckedSwaps=200;
        private void Awake(){ Ensure(); }
        public HintResult FindHint(Block[,] blocks,int rows,int columns){ var all=FindAllHints(blocks,rows,columns); return all.Count>0?all[0]:HintResult.None; }
        public List<HintResult> FindAllHints(Block[,] blocks,int rows,int columns){ Ensure(); var list=new List<HintResult>(); if(blocks==null||matchFinder==null) return list; int n=0; for(int r=0;r<rows;r++)for(int c=0;c<columns;c++){ if(n>=maxCheckedSwaps) return list; var cur=blocks[r,c]; if(!Hintable(cur)) continue; if(c+1<columns){n++; var h=Eval(blocks,rows,columns,cur,blocks[r,c+1]); if(h.hasHint) list.Add(h);} if(r+1<rows){n++; var h=Eval(blocks,rows,columns,cur,blocks[r+1,c]); if(h.hasHint) list.Add(h);} } return list; }
        public bool HasAvailableMove(Block[,] blocks,int rows,int columns)=>FindHint(blocks,rows,columns).hasHint;
        private HintResult Eval(Block[,] blocks,int rows,int cols,Block a,Block b){ if(!Hintable(a)||!Hintable(b)||a==b||!Adjacent(a,b)) return HintResult.None; int ar=a.Row,ac=a.Column,br=b.Row,bc=b.Column; blocks[ar,ac]=b; blocks[br,bc]=a; var matches=matchFinder.FindMatches(blocks,rows,cols); blocks[ar,ac]=a; blocks[br,bc]=b; int count=matches!=null?matches.Count:0; return count>0?new HintResult(a,b,count):HintResult.None; }
        private bool Adjacent(Block a,Block b)=>Mathf.Abs(a.Row-b.Row)+Mathf.Abs(a.Column-b.Column)==1; private bool Hintable(Block b)=>b!=null&&!b.IsEmpty&&!b.IsNoise;
        private void Ensure(){ if(matchFinder==null) matchFinder=GetComponent<MatchFinder>(); if(matchFinder==null) matchFinder=gameObject.AddComponent<MatchFinder>(); }
    }
}
