using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public class Block : MonoBehaviour
    {
        [SerializeField] private BlockType type = BlockType.Empty;
        [SerializeField] private int row;
        [SerializeField] private int column;
        [SerializeField] private bool isSelected;
        public BlockType Type => type; public int Row => row; public int Column => column; public bool IsSelected => isSelected;
        public bool IsEmpty => type == BlockType.Empty; public bool IsNoise => type == BlockType.Noise; public bool IsMatchable => !IsEmpty && !IsNoise;
        public void Initialize(BlockType type, int row, int column){ SetType(type); SetGridPosition(row,column); SetSelected(false); }
        public void SetType(BlockType type){ this.type=type; }
        public void SetGridPosition(int row,int column){ this.row=row; this.column=column; }
        public void SetSelected(bool selected){ isSelected=selected; }
        public bool HasSameType(Block other){ return other!=null && IsMatchable && other.IsMatchable && Type==other.Type; }
        public string GetDebugLabel(){ return $"Block(row={row}, column={column}, type={type}, selected={isSelected})"; }
    }
}
