using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public class BlockDropper : MonoBehaviour
    {
        public int DropBlocks(Block[,] blocks,int rows,int columns,float cellSize,Transform root=null){ if(blocks==null) return 0; int moved=0; for(int c=0;c<columns;c++){ for(int target=rows-1;target>=0;target--){ if(blocks[target,c]!=null) continue; int source=FindAbove(blocks,target,c); if(source<0) continue; var b=blocks[source,c]; blocks[target,c]=b; blocks[source,c]=null; b.SetGridPosition(target,c); var local=Local(target,c,rows,columns,cellSize); b.transform.position=root?root.TransformPoint(local):local; moved++; }} return moved; }
        private int FindAbove(Block[,] blocks,int target,int c){ for(int r=target-1;r>=0;r--) if(blocks[r,c]!=null) return r; return -1; }
        private Vector3 Local(int r,int c,int rows,int cols,float cell){ return new Vector3(-(cols-1)*cell*.5f+c*cell,(rows-1)*cell*.5f-r*cell,0); }
    }
}
