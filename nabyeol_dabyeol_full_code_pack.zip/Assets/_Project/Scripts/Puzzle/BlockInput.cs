using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    [RequireComponent(typeof(Block))]
    public class BlockInput : MonoBehaviour
    {
        [SerializeField] private BoardManager boardManager; private Block block;
        private void Awake(){ block=GetComponent<Block>(); if(boardManager==null) boardManager=FindFirstObjectByType<BoardManager>(); }
        private void OnMouseDown(){ if(block==null||block.IsEmpty||boardManager==null) return; boardManager.OnBlockClicked(block); }
    }
}
