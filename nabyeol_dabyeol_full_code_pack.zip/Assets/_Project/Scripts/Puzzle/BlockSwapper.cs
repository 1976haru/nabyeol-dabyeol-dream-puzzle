using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public class BlockSwapper : MonoBehaviour
    {
        public bool Swap(Block a, Block b, Block[,] blocks)
        {
            if(!CanSwap(a,b,blocks)) return false;
            int ar=a.Row, ac=a.Column, br=b.Row, bc=b.Column; var ap=a.transform.position; var bp=b.transform.position;
            blocks[ar,ac]=b; blocks[br,bc]=a; a.SetGridPosition(br,bc); b.SetGridPosition(ar,ac); a.transform.position=bp; b.transform.position=ap; return true;
        }
        public bool CanSwap(Block a, Block b, Block[,] blocks){ return a!=null&&b!=null&&a!=b&&blocks!=null&&Inside(a,blocks)&&Inside(b,blocks); }
        private bool Inside(Block b, Block[,] blocks){ return b.Row>=0&&b.Row<blocks.GetLength(0)&&b.Column>=0&&b.Column<blocks.GetLength(1); }
    }
}
