namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public enum BlockType
    {
        Empty = 0,
        DreamBubble = 1,
        MoonRiceCake = 2,
        InkStar = 3,
        WaveCloud = 4,
        HeartLight = 5,
        Noise = 6
    }
}
