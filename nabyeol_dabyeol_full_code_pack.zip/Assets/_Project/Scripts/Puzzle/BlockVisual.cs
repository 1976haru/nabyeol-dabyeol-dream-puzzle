using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    [RequireComponent(typeof(Block))]
    public class BlockVisual : MonoBehaviour
    {
        [SerializeField] private SpriteRenderer spriteRenderer;
        [SerializeField] private float selectedScaleMultiplier = 1.12f;
        private Block block; private Vector3 defaultScale;
        private void Awake(){ block=GetComponent<Block>(); if(spriteRenderer==null) spriteRenderer=GetComponent<SpriteRenderer>(); defaultScale=transform.localScale; Refresh(); }
        public void Refresh(){ if(block==null) return; ApplyType(block.Type); SetSelected(block.IsSelected); }
        public void ApplyType(BlockType type){ if(spriteRenderer==null) return; spriteRenderer.color=ColorFor(type); }
        public void SetSelected(bool selected){ transform.localScale = selected ? defaultScale*selectedScaleMultiplier : defaultScale; }
        private Color ColorFor(BlockType t){ switch(t){ case BlockType.DreamBubble:return new Color(.45f,.85f,1,1); case BlockType.MoonRiceCake:return new Color(1,.92f,.45f,1); case BlockType.InkStar:return new Color(.65f,.45f,1,1); case BlockType.WaveCloud:return new Color(.55f,.75f,1,1); case BlockType.HeartLight:return new Color(1,.55f,.75f,1); case BlockType.Noise:return new Color(.18f,.18f,.22f,1); default:return new Color(.6f,.6f,.6f,.25f);} }
    }
}
