using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NabyeolDabyeolDreamPuzzle.Agents;
using NabyeolDabyeolDreamPuzzle.Stage;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public class BoardManager : MonoBehaviour
    {
        [SerializeField,Min(3)] private int rows=6; [SerializeField,Min(3)] private int columns=6;
        [SerializeField] private Block blockPrefab; [SerializeField] private Transform boardRoot; [SerializeField,Min(.1f)] private float cellSize=1.1f;
        [SerializeField] private BlockType[] spawnableTypes={BlockType.DreamBubble,BlockType.MoonRiceCake,BlockType.InkStar,BlockType.WaveCloud,BlockType.HeartLight};
        [SerializeField,Min(1)] private int maxBoardRegenerationAttempts=20; [SerializeField,Min(1)] private int maxCascadeIterations=10;
        [SerializeField] private MatchFinder matchFinder; [SerializeField] private BlockSwapper blockSwapper; [SerializeField] private BlockDropper blockDropper; [SerializeField] private HintAgent hintAgent; [SerializeField] private HintHighlighter hintHighlighter; [SerializeField] private ScoreManager scoreManager; [SerializeField] private MoveManager moveManager;
        private Block[,] blocks; private Block selectedBlock; private bool isBusy;
        public int Rows=>rows; public int Columns=>columns; public Block SelectedBlock=>selectedBlock; public bool IsBusy=>isBusy;
        private void Awake(){ rows=Mathf.Max(3,rows); columns=Mathf.Max(3,columns); EnsureHelpers(); }
        private void Start(){ InitializeBoard(); }
        public void InitializeBoard(){ rows=Mathf.Max(3,rows); columns=Mathf.Max(3,columns); EnsureHelpers(); GenerateBoardOnce(); EnsureBoardHasAvailableMove(); }
        private void GenerateBoardOnce(){ ClearBoardObjects(); blocks=new Block[rows,columns]; if(boardRoot==null) boardRoot=transform; if(blockPrefab==null){Debug.LogWarning("BoardManager: BlockPrefab missing."); return;} for(int r=0;r<rows;r++) for(int c=0;c<columns;c++) CreateBlock(r,c); }
        private void ClearBoardObjects(){ if(blocks==null) return; foreach(var b in blocks) if(b!=null) Destroy(b.gameObject); blocks=null; }
        public Block GetBlock(int r,int c)=>IsInsideBoard(r,c)&&blocks!=null?blocks[r,c]:null; public bool IsInsideBoard(int r,int c)=>r>=0&&r<rows&&c>=0&&c<columns;
        private Block CreateBlock(int r,int c){ var type=RandomTypeAvoidMatch(r,c); var pos=(boardRoot?boardRoot:transform).TransformPoint(LocalPos(r,c)); var b=Instantiate(blockPrefab,pos,Quaternion.identity,boardRoot?boardRoot:transform); b.name=$"Block_{r}_{c}_{type}"; b.Initialize(type,r,c); var v=b.GetComponent<BlockVisual>(); if(v!=null)v.Refresh(); blocks[r,c]=b; return b; }
        public void OnBlockClicked(Block block){ if(isBusy||block==null||block.IsEmpty) return; if(moveManager!=null&&moveManager.IsOutOfMoves) return; if(selectedBlock==null){Select(block);return;} if(selectedBlock==block){Deselect();return;} if(AreAdjacent(selectedBlock,block)){StartCoroutine(SwapAndValidate(selectedBlock,block));return;} Deselect(); Select(block); }
        public bool AreAdjacent(Block a,Block b)=>a!=null&&b!=null&&a!=b&&Mathf.Abs(a.Row-b.Row)+Mathf.Abs(a.Column-b.Column)==1;
        private IEnumerator SwapAndValidate(Block a,Block b){ isBusy=true; ApplySelect(a,false); ApplySelect(b,false); selectedBlock=null; if(blockSwapper==null||!blockSwapper.Swap(a,b,blocks)){isBusy=false;yield break;} yield return null; var matches=FindCurrentMatches(); if(matches.Count>0){ if(!UseMove()){blockSwapper.Swap(a,b,blocks); isBusy=false; yield break;} yield return StartCoroutine(Resolve(matches)); } else blockSwapper.Swap(a,b,blocks); isBusy=false; }
        private IEnumerator Resolve(List<Block> matches){ int cascade=0; while(matches!=null&&matches.Count>0&&cascade<maxCascadeIterations){ cascade++; int removed=RemoveMatchedBlocks(matches); if(removed<=0) break; if(scoreManager!=null) scoreManager.AddMatchScore(removed,cascade); yield return null; if(blockDropper!=null) blockDropper.DropBlocks(blocks,rows,columns,cellSize,boardRoot); yield return null; FillEmpty(); yield return null; matches=FindCurrentMatches(); } }
        public List<Block> FindCurrentMatches()=>blocks!=null&&matchFinder!=null?matchFinder.FindMatches(blocks,rows,columns):new List<Block>(); public bool HasCurrentMatches()=>FindCurrentMatches().Count>0; public void LogCurrentMatches()=>Debug.Log($"Matches: {FindCurrentMatches().Count}");
        private int RemoveMatchedBlocks(List<Block> matches){ int n=0; if(matches==null)return 0; foreach(var b in matches){ if(b==null||!IsInsideBoard(b.Row,b.Column)||blocks[b.Row,b.Column]!=b) continue; blocks[b.Row,b.Column]=null; Destroy(b.gameObject); n++; } return n; }
        private int FillEmpty(){ int n=0; for(int r=0;r<rows;r++)for(int c=0;c<columns;c++) if(blocks[r,c]==null){CreateBlock(r,c); n++;} return n; }
        private bool UseMove(){ if(moveManager==null) return true; return !moveManager.IsOutOfMoves && moveManager.UseMove(); }
        private void Select(Block b){ selectedBlock=b; ApplySelect(b,true); } private void Deselect(){ if(selectedBlock!=null) ApplySelect(selectedBlock,false); selectedBlock=null; }
        private void ApplySelect(Block b,bool s){ if(b==null)return; b.SetSelected(s); var v=b.GetComponent<BlockVisual>(); if(v!=null)v.SetSelected(s); }
        public HintAgent.HintResult RequestHint(){ if(isBusy||blocks==null||hintAgent==null) return HintAgent.HintResult.None; var h=hintAgent.FindHint(blocks,rows,columns); if(h.hasHint&&hintHighlighter!=null) hintHighlighter.Highlight(h.firstBlock,h.secondBlock); Debug.Log(h.hasHint?$"Hint: {h.firstBlock.GetDebugLabel()} -> {h.secondBlock.GetDebugLabel()}":"No hint found"); return h; }
        public void LogHint()=>RequestHint(); public bool HasAvailableMove()=>blocks!=null&&hintAgent!=null&&hintAgent.HasAvailableMove(blocks,rows,columns);
        private bool EnsureBoardHasAvailableMove(){ if(HasAvailableMove()) return true; for(int i=1;i<=maxBoardRegenerationAttempts;i++){ GenerateBoardOnce(); if(HasAvailableMove()) return true; } Debug.LogWarning("BoardManager: no available move after regeneration attempts."); return false; }
        private BlockType RandomTypeAvoidMatch(int r,int c){ for(int i=0;i<20;i++){var t=RandomType(); if(!WouldCreateInitialMatch(r,c,t)) return t;} return RandomType(); }
        private bool WouldCreateInitialMatch(int r,int c,BlockType t){ bool h=c>=2&&blocks[r,c-1]!=null&&blocks[r,c-2]!=null&&blocks[r,c-1].Type==t&&blocks[r,c-2].Type==t; bool v=r>=2&&blocks[r-1,c]!=null&&blocks[r-2,c]!=null&&blocks[r-1,c].Type==t&&blocks[r-2,c].Type==t; return h||v; }
        private BlockType RandomType(){ var safe=SafeTypes(); return safe[Random.Range(0,safe.Length)]; }
        private BlockType[] SafeTypes(){ var list=new List<BlockType>(); if(spawnableTypes!=null) foreach(var t in spawnableTypes) if(t!=BlockType.Empty&&t!=BlockType.Noise) list.Add(t); return list.Count>0?list.ToArray():new[]{BlockType.DreamBubble,BlockType.MoonRiceCake,BlockType.InkStar,BlockType.WaveCloud,BlockType.HeartLight}; }
        private Vector3 LocalPos(int r,int c)=>new Vector3(-(columns-1)*cellSize*.5f+c*cellSize,(rows-1)*cellSize*.5f-r*cellSize,0);
        private void EnsureHelpers(){ if(boardRoot==null)boardRoot=transform; if(matchFinder==null)matchFinder=GetComponent<MatchFinder>(); if(matchFinder==null)matchFinder=gameObject.AddComponent<MatchFinder>(); if(blockSwapper==null)blockSwapper=GetComponent<BlockSwapper>(); if(blockSwapper==null)blockSwapper=gameObject.AddComponent<BlockSwapper>(); if(blockDropper==null)blockDropper=GetComponent<BlockDropper>(); if(blockDropper==null)blockDropper=gameObject.AddComponent<BlockDropper>(); if(hintAgent==null)hintAgent=GetComponent<HintAgent>(); if(hintAgent==null)hintAgent=gameObject.AddComponent<HintAgent>(); if(hintHighlighter==null)hintHighlighter=GetComponent<HintHighlighter>(); if(hintHighlighter==null)hintHighlighter=gameObject.AddComponent<HintHighlighter>(); if(scoreManager==null)scoreManager=FindFirstObjectByType<ScoreManager>(); if(moveManager==null)moveManager=FindFirstObjectByType<MoveManager>(); }
    }
}
