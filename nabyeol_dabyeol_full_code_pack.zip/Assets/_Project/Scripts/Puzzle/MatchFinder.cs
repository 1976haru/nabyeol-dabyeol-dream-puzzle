using System.Collections.Generic;
using UnityEngine;
namespace NabyeolDabyeolDreamPuzzle.Puzzle
{
    public class MatchFinder : MonoBehaviour
    {
        public List<Block> FindMatches(Block[,] blocks, int rows, int columns)
        {
            var set=new HashSet<Block>(); if(blocks==null||rows<3||columns<3) return new List<Block>();
            for(int r=0;r<rows;r++){ int c=0; while(c<columns){ var b=blocks[r,c]; if(!Ok(b)){c++; continue;} int s=c; c++; while(c<columns&&Same(b,blocks[r,c])) c++; if(c-s>=3) for(int i=s;i<c;i++) if(blocks[r,i]!=null) set.Add(blocks[r,i]); }}
            for(int c=0;c<columns;c++){ int r=0; while(r<rows){ var b=blocks[r,c]; if(!Ok(b)){r++; continue;} int s=r; r++; while(r<rows&&Same(b,blocks[r,c])) r++; if(r-s>=3) for(int i=s;i<r;i++) if(blocks[i,c]!=null) set.Add(blocks[i,c]); }}
            return new List<Block>(set);
        }
        private bool Ok(Block b)=>b!=null&&b.IsMatchable; private bool Same(Block a,Block b)=>Ok(a)&&Ok(b)&&a.Type==b.Type;
    }
}
